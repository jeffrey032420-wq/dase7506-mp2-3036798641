# 最终冻结模型：Round137联合更新版

冻结时间：2026-10-30T00:24:58.993181+08:00。用户明确选定round137_joint_l1p0，停止此版本的训练和调参。

|项目|记录|
|---|---|
|模型|四模块联合更新，5180个排序权重，λ=1|
|训练三折OOF|4406/4755（选择λ后的开发指标）|
|官方validation|752/798，94.2355889724%|
|官方test|395/467，84.58244111349036%|
|全部递归未压缩推理资产|62,449字节|
|本机完整test预测+独立评分|2.331497200008016秒，4总CPU线程|
|公开提交|未提交|

## 冻结与选定披露

训练与λ在测试前仅用train OOF确定；原开发选择仍是123。用户在看到多轮测试成绩之后明确指定本模型为最终版本，因此测试成绩参与了最终人工选定。课程guide要求测试不用于选型，本次最终选定流程与该要求存在差异，报告必须如实说明，不能写成测试完全未参与最终选择，也不将84.58%称为独立泛化估计。

本目录保存用户最终选定后的版本；provenance中的“保留123、未按test选提交模型”等文字记录当时历史阶段。原首次测试前清单、官方分数、训练参数和全部历史包保持原样。当前状态以FROZEN_MODEL.json及本README为准。

## 免重训复现

安装code/requirements.txt。在本包code目录运行，将外部数据路径换成官方完整code/data。checkpoint只需checkpoint/config.json和checkpoint/parameters.npz，两个文件必须同时保留；本模型运行时无需旧父checkpoint。

```powershell
$env:OMP_NUM_THREADS = "4"
$env:OPENBLAS_NUM_THREADS = "4"
$env:MKL_NUM_THREADS = "4"
$env:NUMEXPR_NUM_THREADS = "4"
$env:VECLIB_MAXIMUM_THREADS = "4"
$env:BLIS_NUM_THREADS = "4"
python -X utf8 predict.py --method method_round137_joint_retrain.py --checkpoint checkpoint --data-dir "C:\path\to\DASE7506-MP2\code\data" --split test --output test-predictions.json
python -X utf8 score_predictions.py --split test --data-dir "C:\path\to\DASE7506-MP2\code\data" --predictions test-predictions.json --output test-score.json
```

复现validation时将两条命令的split/output/predictions对应改为validation。冻结过程没有重新训练、预测或评分，scores为已完成的原官方聚合JSON，SHA已核对。参考Xeon资格尚未认证。数据、参考答案和逐题test预测不随包分发。

## 完整训练与提交状态

完整训练源、原父折中心与实验记录在原项目code及runs，训练命令见provenance/ROUND137_LEARNING.md。此包用于不重新训练的模型复现；课程最终<=10页报告、公开代码与checkpoint链接、网站及实际GitHub issue提交仍待完成。AI实质参与实现、训练、评价、分析和冻结，需按AI_DISCLOSURE.md披露。
